#include"alg/pch.h"

std::vector<std::string> StringUtils::explode(std::string &str, char delimiter)
{
std::vector<std::string> pics;
std::istringstream iss(str);
std::string item;
while (getline(iss, item, delimiter)) {
	pics.push_back(item);
}
return pics;
}