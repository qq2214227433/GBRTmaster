#include "alg/pch.h"

HANDLE color::hstdin1 = NULL;
HANDLE color::hstdout1 = NULL;
void color::setcolor(const char *a)
{

	if (!hstdin1|| !hstdout1)
	{
		HANDLE hstdin = freopen("conin$", "r", stdin);
		HANDLE hstdout = freopen("conout$", "w", stdout);
	}

	WORD index = 0;
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	GetConsoleScreenBufferInfo(hstdout1, &csbi);
	if (a == "yellow")
	{
		SetConsoleTextAttribute(hstdout1, 0x0E);

	}
	else if (a == "red")
	{
		SetConsoleTextAttribute(hstdout1, 0x0C);

	}
	else if (a == "green")
	{
		SetConsoleTextAttribute(hstdout1, 0x0A);

	}
	else
	{
		SetConsoleTextAttribute(hstdout1, 0x0F);

	}

	}