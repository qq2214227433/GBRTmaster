#include "alg/pch.h"
GBDT* MainWindow::gbdt = nullptr;
GBDT* MainWindow::gbdtp = nullptr;
static std::string model_file = "./gbrtmaster.model";
static std::string input_file = "./train.csv";
static std::string test_file = "./test.csv";
using namespace std;
char TestPath[MAX_PATH];
char TrainPath[MAX_PATH];
char TestResultPath[MAX_PATH];
char ValidationResultPath[MAX_PATH];
void Usage(QTextEdit *text)
{
	GetCurrentDirectoryA(MAX_PATH, TrainPath);
	strcat_s(TrainPath, "\\train.csv");
	GetCurrentDirectoryA(MAX_PATH, TestPath);
	strcat_s(TestPath, "\\test.csv");
	GetCurrentDirectoryA(MAX_PATH, TestResultPath);
	strcat_s(TestResultPath, "\\TestResult.csv");
	GetCurrentDirectoryA(MAX_PATH, ValidationResultPath);
	strcat_s(ValidationResultPath, "\\ValidationResult.csv");
	text->append(QString::fromLocal8Bit("School:CSU-���ϴ�ѧ"));
	text->append("<br/>");
	text->append(QString::fromLocal8Bit("Tutor:��ï"));
	text->append("<br/>");
	text->append(QString::fromLocal8Bit("Brief: ���ڵ�������Ĵ������ܺķ���"));
	text->append("<br/>");
	text->append(QString::fromLocal8Bit("Author: �²���"));
	text->append("<br/>");
	text->append(QString::fromLocal8Bit("Tutor:Address: 2214227433@qq.com"));
	text->append("<br/>");
	text->append(QString::fromLocal8Bit("Studentid:1006150323"));
	text->append("<br/>");
	text->append(QString::fromLocal8Bit("Tutor:Address: 2214227433@qq.com"));
	text->append("<br/>");

}
int iiinit(GBDT *gbdt,QTextEdit*text)
{
	AllocConsole();
	freopen("conin$", "r", stdin);
	freopen("conout$", "w", stdout);
	freopen("conout$", "w", stderr);
	DataReader dr = DataReader(text);
	Usage(text);
	std::string input_file = TrainPath;
	std::string input_type = "cvs";
	std::string config_file = "./gbrtmaster.conf";
	std::string act_type = "";
	std::string model_file = "./gbrtmaster.model";
	int dimention = 1024;




	Data data(text);
	if (false == dr.ReadDataFromCVS(TrainPath, data))//��CSV�ļ���ȡ���ݵ�data
	{
		color::setcolor("red");
		std::cerr << "error: read CVS file failed! " << input_file << std::endl;
	}


	if (!gbdt->LoadConfig(config_file))
		return 1;


	gbdt->Init();
	gbdt->Train(data);
	gbdt->SaveWeights(model_file);//����ɭ�����ݵ�����

	return 0;
}
static int id = 0;
void MainWindow::rbtree_fprint_node(node * t, FILE *fp,int id) {
	fprintf(fp, "node[shape=record,style=filled,color=red,fontcolor=white];\n");
	if(t->node_best_feature_id==-3)
	{
		fprintf(fp, "%d[label=\"<f0> | <f1> feature_id:NULL || <f2> Prediction_Value:%lf  | <f3> sampe_count:%d|<f4> \"];\n", t, t->node_split_value,t->node_this_node_sample_count);
		return;
	}
	fprintf(fp, "%d[label=\"<f0> | <f1> feature_id:%d || <f2> feature_value:%lf | <f3> sampe_count:%d|<f4> \"];\n", t, t->node_best_feature_id,t->node_split_value,t->node_this_node_sample_count);
}
void MainWindow::rbtree_fprint_tree(node * t, FILE *fp) {
	if (t==NULL) return;
	if (id==0) {//root
		rbtree_fprint_node(t, fp,0);
	}
	if (t->node_toSmaller_ptr) {
		rbtree_fprint_node(t->node_toSmaller_ptr, fp,2*id+1);
		fprintf(fp, "%d:f0:sw->%d:f1;\n", t, t->node_toSmaller_ptr);
	}
	if (t->node_toLarger_ptr ) {
		rbtree_fprint_node(t->node_toLarger_ptr, fp, 2*id+2);
		fprintf(fp, "%d:f2:se->%d:f1;\n", t, t->node_toLarger_ptr);
	}
	++id;
	rbtree_fprint_tree(t->node_toSmaller_ptr, fp);
	rbtree_fprint_tree(t->node_toLarger_ptr, fp);
}












void MainWindow::createLeft() {
	//��ť
	buttonTrain = new QPushButton(this);
	buttonTrain->setText(QString::fromLocal8Bit("ѵ������Train"));
	buttonTrain->setFixedSize(200, 30);
	connect(buttonTrain, SIGNAL(clicked()), this, SLOT(onBtnCalcClickedTrain()));//�źŲ�
	buttonTrain->move(0, 0);
	buttonPredict = new QPushButton(this);
	buttonPredict->setText(QString::fromLocal8Bit("Ԥ��Predict"));
	buttonPredict->setFixedSize(200, 30);
	buttonPredict->move(0, 30);
	connect(buttonPredict, SIGNAL(clicked()), this, SLOT(OnBtnPredict()));
	buttonpaint = new QPushButton(this);
	buttonpaint->setText(QString::fromLocal8Bit("���ƶ�����Paint"));
	buttonpaint->setFixedSize(200, 30);
	buttonpaint->move(0, 60);
	connect(buttonpaint, SIGNAL(clicked()), this, SLOT(OnBtnPaint()));
	//��Ϣ��
	msg=new QMessageBox(this);//�Ի������ø����
	msg->setWindowTitle(QString::fromLocal8Bit("CSU-���ϴ�ѧ"));//�Ի������
	msg->setText("Predict successfully and the data had been saved!");//�Ի�����ʾ�ı�
	msg->setIcon(QMessageBox::Information);//����ͼ������
	msg->setStandardButtons(QMessageBox::Ok);//�Ի����ϰ����İ�ť
	//�ı���
	textEdit = new QTextEdit(this);
	textEdit->setGeometry(QRect(0, 90, 200, 840));
	textEdit->setWordWrapMode(QTextOption::NoWrap);
}
void MainWindow::OnBtnPredict()
{
	Data data_p= Data(this->textEdit);
	DataReader dr = DataReader(this->textEdit);
	T_VECTOR predictions;
	gbdtp = new GBDT();
	if (!gbdtp)return;
	if (!dr.ReadDataFromCVS(test_file.c_str(), data_p))
	{
		msg->setText(QString::fromLocal8Bit("����δ�ҵ�Ԥ�������ļ�"));
		msg->exec();
		return;
	}

	if (!gbdtp->LoadWeights(model_file, this->textEdit)) {
		msg->setText(QString::fromLocal8Bit("����δ�ҵ�ѵ���󱣴��Ȩ��"));
		msg->exec();
		return;
	}
	gbdtp->PredictAllOutputs(data_p, predictions);

	//----output prediction----
	std::ifstream fs;
	fs.open(input_file.c_str(), std::ios_base::in);

	std::string prediction_file = "prediction.csv";
	std::fstream fs_out;
	fs_out.open(prediction_file.c_str(), std::ios_base::out);
	std::string strLine;
	unsigned int line_num = 0;
	double O1;//��ĺ��ܺĵ�ԭʼֵ��Ԥ��ֵ
	double P1;
	double O2;
	double P2;
	getline(fs, strLine);
	getline(fs, strLine);
	getline(fs, strLine);
	getline(fs, strLine);
	auto a = predictions[line_num];
	bool title = 0;
	while (getline(fs, strLine))
	{
		if (strLine.length() < 2)
		{
			continue;
		}
		if (!title)
		{
			fs_out << "������Ԥ��ֵ(��),���������(%),��Ч��Ԥ��ֵ(%),��Ч�����(%),���Ԥ��ֵ(kw.h),������(%)"<< std::endl;
			title = true;
			continue;
		}
		double O1 = 100*data_p.data_Al[line_num]/ data_p.I[line_num];
		double P1 = 100*predictions[line_num] / data_p.I[line_num];
		double O2 = 2980* data_p .U[line_num]/ O1;
		double P2 = 2980* data_p.U[line_num] / P1;
		fs_out << predictions[line_num] <<","<< 100*(predictions[line_num]- data_p.data_Al[line_num])/ data_p.data_Al[line_num] << "," << P1 <<"," << 100*(P1-O1)/01 << "," << P2 << "," << 100*(P2-O2)/P2<< std::endl;

		line_num++;
	}
	fs.close();
	msg->setText("Predict successfully and the data had been saved!");//�Ի�����ʾ�ı�
	msg->exec();
}
MainWindow::MainWindow(){
	setWindowIcon(QIcon("C:\\Users\\Administrator\\source\\repos\\QtGuiApplication1\\QtGuiApplication1\\favicon.ico"));
	setWindowTitle(QString::fromLocal8Bit("����GBRT�Ĵ������ܺķ���"));
	resize(900, 900);
	createLeft();
	//��������
	scroll = new QScrollArea(this);//���������
	scroll->setGeometry(200, 0, 700, 900);//(0,0)��ʼ 200��200��ķ�ΧΪ����
	scroll->setVerticalScrollBarPolicy(Qt::ScrollBarAlwaysOff);
	paintarea = new RenderArea();
	//���ù�������Ĵ���
	scroll->setWidget(paintarea);
	paintarea->setGeometry(0, 0, 5000, 5000);
}

void MainWindow::onBtnCalcClickedTrain() {
	fstream fff(input_file.c_str());
	if (!fff)
	{
		msg->setText(QString::fromLocal8Bit("��ǰĿ¼��û��ѵ�����ϣ�����"));//�Ի�����ʾ�ı�
		msg->exec();
		return;
	}
	MainWindow::gbdt = new GBDT();
	iiinit(gbdt,textEdit);
	msg->setText(QString::fromLocal8Bit("ѵ����ϣ�����"));//�Ի�����ʾ�ı�
	msg->exec();
}

void MainWindow::OnBtnPaint() {
	
	if (!gbdt)
	{
		msg->setText(QString::fromLocal8Bit("���Ƚ�������ѵ��������"));//�Ի�����ʾ�ı�
		msg->exec();
		return;
	}
	node *t = &gbdt->GBDT_every_tree_first_node_array[0];
	FILE *fp;
	fp = fopen("g2.dot", "w+");
	fprintf(fp, "digraph G{\n");
	rbtree_fprint_tree(t, fp);
	fprintf(fp, "}");
	fclose(fp);
	msg->setText(QString::fromLocal8Bit("��ͼ��ϣ�����"));//�Ի�����ʾ�ı�
	msg->exec();
	
	

}

std::string MainWindow::Lpcwstr2String1(LPCWSTR lps) {
	int len = WideCharToMultiByte(CP_ACP, 0, lps, -1, NULL, 0, NULL, NULL);
	if (len <= 0) {
		return "";
	}
	else {
		char *dest = new char[len];
		WideCharToMultiByte(CP_ACP, 0, lps, -1, dest, len, NULL, NULL);
		dest[len - 1] = 0;
		std::string str(dest);
		delete[] dest;
		return str;
	}
}