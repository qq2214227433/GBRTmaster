#ifndef PROJECT_MAIN_WINDOW_HPP
#define PROJECT_MAIN_WINDOW_HPP

#include <iostream>
#include <sstream>
#include <QWidget>
#include <QPainter>
#include <QPushButton>
#include <QHBoxLayout>
#include <QGroupBox>
#include <QTextEdit>
#include <Windows.h>
#include <string.h>
#include "render_area.h"
#include "../utils/string_utils.h"
#include <QScrollArea>
#include  <qmessagebox.h>
#include <qtextedit.h>
#include <QFile>

class MainWindow: public QWidget {
    Q_OBJECT

protected:
	QScrollArea *scroll;
	QMessageBox *msg;
	QWidget *paintarea;
	QPushButton *buttonTrain;
	QPushButton *buttonPredict;
	QPushButton *buttonpaint;
    RenderArea *renderArea;
	QTextEdit* textEdit;
	void createLeft();
 

public:
	static GBDT *gbdt;
	static GBDT *gbdtp;
	MainWindow();
    virtual ~MainWindow() {}
	
	static std::string Lpcwstr2String1(LPCWSTR lps);

public slots://
	void onBtnCalcClickedTrain();
	void OnBtnPredict();
	void OnBtnPaint();
private:
	int(*fc)(GBDT*);
	int Show_Tree_id;
	void rbtree_fprint_node(node * t, FILE *fp,int id);
	void rbtree_fprint_tree(node * t, FILE *fp);
	
};

#endif //PROJECT_MAIN_WINDOW_HPP
