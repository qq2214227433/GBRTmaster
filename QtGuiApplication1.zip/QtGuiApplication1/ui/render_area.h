#ifndef PROJECT_RENDER_AREA_HPP
#define PROJECT_RENDER_AREA_HPP

#include <iostream>
#include <math.h>
#include <QWidget>
#include <QPainter>
#include <QRect>
#include <QString>
#include "alg/gbdt.h"
#include <sstream>
#include <QScrollArea>




struct stackNode
{
	node* treeNode;
	int layer;      // ��Ǹýڵ����ڵڼ���
};

class RenderArea: public QWidget {
private:
	bool show = false;
	int GetTreeHeight(node *a);
protected:
    int middleLine = 250;
    int topPadding = 30;
    int nodeOffset = 60;
    int levelHeight = 60;
    int boxHeight = 15;
    int boxWidth = 30;
    int radius = 20;
public:
	RenderArea();
	static void convertDouble(float value,  char *array);

protected:
	void paintEvent(QPaintEvent *event) override;
  
};


#endif //PROJECT_RENDER_AREA_HPP
