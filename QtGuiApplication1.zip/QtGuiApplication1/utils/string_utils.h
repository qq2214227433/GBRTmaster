//
// Created by Yaphper on 2018/12/31.
//

#ifndef PROJECT_STRING_UTILS_HPP
#define PROJECT_STRING_UTILS_HPP

#include <string>
#include <sstream>
#include <vector>

class StringUtils {
public:
	static std::vector<std::string> explode(std::string &str, char delimiter);
};


#endif //PROJECT_STRING_UTILS_HPP
