﻿/// @Brief: A simple implement of gbrt, parallelization with tbb lib
/// @Date: 2019年2月24日 11:10:04
/// @Author: chenbowen
/// @address: 2214227433@qq.com

#include "pch.h"
#ifdef WIN32
#pragma execution_character_set("utf-8")
#endif


int main(int argc, char *argv[])
{
	
	QApplication application(argc, argv);
 	MainWindow mainWindow;
	mainWindow.show();
	return QApplication::exec();
}

