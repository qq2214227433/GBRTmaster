﻿#ifndef PCH_H
#define PCH_H
#include <stdio.h>
#include <iostream>
#include <fstream>
#include <string>
#include <deque>
#include <algorithm>
#include <set>
#include <sstream>
#include <stdlib.h>
#include <math.h>
#include <assert.h>
#include <time.h>
#include <sstream>
#include <errno.h>
#include <tchar.h>
#include <iostream>
#include <map>
#include <list>
#include <string>
#include <QApplication>
#include <Windows.h>

#include <QScrollArea>
#include <qmessagebox.h>
#include <QtCore/QTextCodec>
#include <qtextedit.h>
#include <QFile>
#include <QDebug>

#include "alg/color.h"
#include "utils/string_utils.h"
#include "ui/main_window.h"
#include "ui/render_area.h"
#include "gbdt.h"
#include "types.h"
#include "data.h"
#include "gbdt.h"

#include "color.h"
#endif 
