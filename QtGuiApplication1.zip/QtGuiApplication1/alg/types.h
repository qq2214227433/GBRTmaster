#ifndef __TYPES_H__
#define __TYPES_H__

#include <vector>

typedef float T_DTYPE;
typedef std::vector< std::vector<T_DTYPE> > T_MATRIX;
typedef std::vector<T_DTYPE> T_VECTOR;

#endif