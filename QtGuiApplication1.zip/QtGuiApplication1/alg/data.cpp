#include "pch.h"
static void InplaceTrimLeft(std::string& strValue)
{
	size_t pos = 0;
	for (size_t i = 0; i < strValue.size(); ++i)
	{
		if (isspace((unsigned char)strValue[i]))
			++pos;
		else
			break;
	}
	if (pos > 0)
		strValue.erase(0, pos);
}

static void InplaceTrimRight(std::string& strValue)
{
	size_t n = 0;
	for (size_t i = 0; i < strValue.size(); ++i)
	{
		if (isspace((unsigned char)strValue[strValue.length() - i - 1]))
			++n;
		else
			break;
	}
	if (n != 0)
		strValue.erase(strValue.length() - n);
}

static void InplaceTrim(std::string& strValue)
{
	InplaceTrimRight(strValue);
	InplaceTrimLeft(strValue);
}

static bool Split(
	const std::string& strMain,
	char chSpliter,
	std::vector<std::string>& strList,
	bool bReserveNullString)
{
	int Vaule_Id = 0;
	strList.clear();

	if (strMain.empty())
		return false;

	size_t nPrevPos = 0;
	size_t nPos;
	std::string strTemp;
	std::string Al;
	while ((nPos = strMain.find(chSpliter, nPrevPos)) != std::string::npos)
	{
		strTemp.assign(strMain, nPrevPos, nPos - nPrevPos);
		InplaceTrim(strTemp);
		if (bReserveNullString || !strTemp.empty())
		{
		
			if (Vaule_Id % 2 == 0)//ֻ��ȡ�ۼƵ����ݲ���ȡÿ�յ�����
			{
				
				if (strTemp == "��ƽ��" || strTemp== "")
				{

					return false;
				}
				else if (Vaule_Id == 20)//��¼�³�������
				{
					Al = strTemp;
					
				}
				else if(Vaule_Id == 32)//�ų���Ч��
				{
				}
				else {
					strList.push_back(strTemp);
				}
				
			}
			++Vaule_Id;

		}

		nPrevPos = nPos + 1;
	}

	strTemp.assign(strMain, nPrevPos, strMain.length() - nPrevPos);//����kwh����
	InplaceTrim(strTemp);

	if (bReserveNullString || !strTemp.empty())
	{

		strList.push_back(Al);
	}
	return true;
}

bool DataReader::ReadDataFromCVS(const char* input_file, Data& data)
{
	std::ifstream fs;
	fs.open(input_file, std::ios_base::in);

	if (fs.fail())
	{
		
		textEdit->append(" Sorry ! Under the TrainPath the .csv file isn't exist. ");
		textEdit->append(input_file);//��ͬĿ¼���ļ�������
		textEdit->append("<br/>");
		return false;
	}

	std::string strLine;
	unsigned int line_num = 0;//�к�
	getline(fs, strLine);//������һ��
	getline(fs, strLine);//�����ڶ���
	getline(fs, strLine);//����������

	while(getline(fs, strLine))//��ȡһ������,�ۺſ�����һ������
	{
		if (!strLine.empty())
		{
			std::vector<std::string> vecResult;
			if (!Split(strLine, ',', vecResult, true))//�Զ��ŷָ����ı�
			{
				continue;
			}
			if (vecResult.size() >= 2)//�ж�����������Ŀ�Ƿ�С��2
			{
				data.data_data.resize(line_num + 1);
				T_VECTOR & fv = data.data_data[line_num];

				T_DTYPE f_value = 0;
				for (size_t i = 0; i < vecResult.size() - 1; ++i)//�ַ���ת��Ϊfloat��������ֵ
				{
					char ** endptr = NULL;
					f_value = strtof(vecResult[i].c_str(), endptr);
					if (i==3)//ƽ����ѹ
					{
						data.U.push_back(f_value);
					}
					if (i == 12)//ƽ������
					{
						data.I.push_back(f_value);
					}
					if (errno == ERANGE)
					{
						color::setcolor("red");
						std::cerr << " feature out of the range: " << vecResult[i] << std::endl;
					}
					if (endptr != NULL && endptr[0] == vecResult[i].c_str())
					{
						color::setcolor("red");
						std::cerr << " feature format wrong: " << vecResult[i] << std::endl;
						
					}

					fv.push_back(f_value);
				}

				unsigned int target_index = vecResult.size() - 1;//�ַ���ת��Ϊfloat��������Kw,h
				char ** endptr = NULL;
				f_value = strtof(vecResult[target_index].c_str(), endptr);
				if (errno == ERANGE)
				{
					color::setcolor("red");
					std::cerr << " target out of the range: " << vecResult[target_index] << std::endl;
				}
				if (endptr != NULL && endptr[0] == vecResult[target_index].c_str())
				{
					color::setcolor("red");
					std::cerr << " target format wrong: " << vecResult[target_index] << std::endl;
				}
				data.data_Al.push_back(f_value);

				if (line_num == 0)//ֻ��һ�������������� ����cpu����
				{
					data.data_all_features_count = data.data_data[0].size();//�����ܸ���
				}
				line_num++;
			}
			else
			{
				color::setcolor("red");
				std::cerr << " sorry maybe the train.csv need the column more than 2 every row" << std::endl;
			}
		}
	}
	if (data.data_data.size() > 0)
	{
		data.data_all_sample_count = data.data_data.size();//��������
	}
	else
	{
		return false;
	}





	for (int i = 0; i < data.data_all_features_count; i++) data.data_not_used_features_id.insert(i);




	textEdit->append(QString::fromLocal8Bit("��ȡtrain.scv�������<br/>"));
	textEdit->append(input_file);
	textEdit->append("<br/>");
	return true;
}


bool DataReader::ReadDataFromL2R(const std::string& input_file, Data& data, unsigned int dimentions)
{
	std::ifstream fs;
	fs.open(input_file.c_str(), std::ios_base::in);

	if (fs.fail())
	{
		std::cerr << " Sorry ! The file isn't exist. " << input_file << std::endl;
		return false;
	}

	data.data_all_features_count = dimentions;
	std::string strLine;
	unsigned int line_num = 0;
	while (getline(fs, strLine))
	{
		if (!strLine.empty())
		{
			size_t pos = strLine.find("#");
			if (pos != strLine.npos && pos > 0)
			{
				pos--;
				while (pos > 0 && strLine.at(pos) == ' ')
					pos--;
				pos++;
				strLine = strLine.substr(0, pos);
			}
			std::vector<std::string> vecResult;
			Split(strLine, ' ', vecResult, true);
			if (vecResult.size() < 3)
				Split(strLine, '\t', vecResult, true);
			if (vecResult.size() >= 3)
			{
				data.data_data.resize(line_num + 1);
				T_VECTOR & fv = data.data_data[line_num];
				fv.resize(dimentions);

				//read target
				const unsigned int target_index = 0;
				char ** endptr = NULL;
				T_DTYPE target_value = strtof(vecResult[target_index].c_str(), endptr);
				if (errno == ERANGE)
				{
					std::cerr << " target out of the range: " << vecResult[target_index] << std::endl;
					continue;
				}
				if (endptr != NULL && endptr[0] == vecResult[target_index].c_str())
				{
					std::cerr << " target format wrong: " << vecResult[target_index] << std::endl;
					continue;
				}
				data.data_Al.push_back(target_value);


				for (size_t i = 2; i < vecResult.size(); ++i)
				{
					int f_index = -1;
					T_DTYPE f_value = 0.0;
					int ret = scanf_s(vecResult[i].c_str(), "%d:%f", &f_index, &f_value);
					if (ret != 2 || f_index >= (int)dimentions)
					{
						std::cerr << " feature format wrong: " << line_num << "\t"
							<< vecResult[i] << std::endl;
						continue;
					}
					fv[f_index] = f_value;
					data.data_not_used_features_id.insert(f_index);
				}

				line_num++;
			}
			else
			{
				
			}
		}
	}
	if (data.data_data.size() > 0)
	{
		data.data_all_sample_count = data.data_data.size();
	}
	else
	{
		return false;
	}

	std::cout << "data_features_number: " << data.data_all_features_count << std::endl;
	std::cout << "data_sample_number: " << data.data_all_sample_count << std::endl;
	std::cout << "valid feature size: " << data.data_not_used_features_id.size() << std::endl;

	return true;
}