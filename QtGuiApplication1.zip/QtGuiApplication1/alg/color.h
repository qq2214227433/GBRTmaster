#pragma once
#include <stdlib.h>
#include <windows.h>
class color
{
	static HANDLE hstdin1;
	static HANDLE hstdout1;
public:
	static void setcolor(const char *a);
};
