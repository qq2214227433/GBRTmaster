#ifndef DATA_H__
#define DATA_H__

#include <vector>
#include <string>
#include <set>
#include "types.h"
#include <qtextedit.h>
class Data
{
public:
	Data(QTextEdit*textEdi1t) { this->textEdit = textEdi1t; }
	std::vector<double> U;
	std::vector<double> I;
	~Data() {}
public:

	T_MATRIX data_data;//vector<vector<float>>������ֵ
	T_VECTOR data_Al;//vector<float>���ֵ
	std::set<unsigned int>    data_not_used_features_id;
	unsigned int data_all_features_count;//�����ܸ���
	unsigned int data_all_sample_count;//��������
private:
	QTextEdit*textEdit;
}; //end of class Data

class DataReader
{
public:
	DataReader(QTextEdit*textEdi1t) { this->textEdit = textEdi1t;}

	~DataReader() {}

	bool ReadDataFromL2R(const std::string& input_file, Data& data, unsigned int data_features_nmuber);

	bool ReadDataFromCVS(const char *input_file, Data& data);

private:
	QTextEdit * textEdit;
}; //end of class DataReader


#endif /* __ML_DATA_H__ */
