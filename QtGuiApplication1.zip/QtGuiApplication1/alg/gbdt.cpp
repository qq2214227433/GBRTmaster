#include "pch.h"
using std::cout;
using std::endl;
using std::deque;
using std::set;
using std::string;
int gettimeofday(struct timeval *tp, void *tzp)
{
	time_t clock;
	struct tm tm;
	SYSTEMTIME wtm;
	GetLocalTime(&wtm);
	tm.tm_year = wtm.wYear - 1900;
	tm.tm_mon = wtm.wMonth - 1;
	tm.tm_mday = wtm.wDay;
	tm.tm_hour = wtm.wHour;
	tm.tm_min = wtm.wMinute;
	tm.tm_sec = wtm.wSecond;
	tm.tm_isdst = -1;
	clock = mktime(&tm);
	tp->tv_sec = clock;
	tp->tv_usec = wtm.wMilliseconds * 1000;
	return (0);
}
static bool compareNodeReduced(NodeToReduce n0, NodeToReduce n1)
{
	return n0.NodeToReduce_sample_count < n1.NodeToReduce_sample_count;//�Ӵ�С����
}
static bool compare_kwh_mean(std::pair<T_DTYPE, int> n0, std::pair<T_DTYPE, int> n1)
{
	return n0.first < n1.first;//��С����
}

static int64_t Milliseconds()
{
	struct timeval t;
	gettimeofday(&t, NULL);
	int64_t curTime;
	curTime = t.tv_sec;
	curTime *= 1000;              // sec -> msec    
	curTime += t.tv_usec / 1000;  // usec -> msec    
	return curTime;
}

GBDT::GBDT()
{
	GBDT_tree_count = 400;
	GBDT_mean_kwh = 0.0;
	GBDT_one_tree_max_node_count = 20;
	GBDT_choose_features_count = 10;//���ɭ��ѡ�������Ĭ��Ϊ10
	GBDT_use_opt_splitpoint = true;
	GBDT_learn_rate = 0.01;
	GBDT_train_epoch = 0;
	GBDT_data_sample_ratio = 0.4;//���ѡ����������(�з���bootstraping)
}


bool GBDT::LoadConfig(const std::string& conf_file)
{
	std::ifstream fs;
	fs.open(conf_file.c_str(), std::ios_base::in);

	if (fs.fail())
	{
		std::cerr << " Warning! The Config File isn't exist!So i will use the defualt config and the result maybe not exact" << conf_file << std::endl;
		return true;
	}

	std::string line;
	while (getline(fs, line))
	{
		string::size_type pos = line.find("=");
		if (pos != string::npos && pos != (line.length() - 1))
		{
			string key = line.substr(0, pos);
			string value = line.substr(pos + 1);

			std::stringstream sstream;
			if (key == "GBDT_tree_count")
			{
				sstream << value;
				sstream >> GBDT_tree_count;
			}
			else if (key == "GBDT_one_tree_max_node_count")
			{
				sstream << value;
				sstream >> GBDT_one_tree_max_node_count;
			}
			else if (key == "GBDT_choose_features_count")
			{
				sstream << value;
				sstream >> GBDT_choose_features_count;
			}
			else if (key == "GBDT_use_opt_splitpoint")
			{
				if (value == "false") GBDT_use_opt_splitpoint = false;
				if (value == "true") GBDT_use_opt_splitpoint = true;
			}
			else if (key == "GBDT_learn_rate")
			{
				sstream << value;
				sstream >> GBDT_learn_rate;
			}
			else if (key == "GBDT_data_sample_ratio")
			{
				sstream << value;
				sstream >> GBDT_data_sample_ratio;
				if (GBDT_data_sample_ratio > 1)
				{
					GBDT_data_sample_ratio = 1;
				}
				else if (GBDT_data_sample_ratio < 0)
				{
					GBDT_data_sample_ratio = 0.01;
				}
			}
		}
	}
	return true;
}

bool GBDT::Init()
 {
	GBDT_every_tree_first_node_array = new node[GBDT_tree_count];
	for (unsigned int i = 0; i < GBDT_tree_count; ++i)//��ʼ��ÿ���ڵ�
	{
		GBDT_every_tree_first_node_array[i].node_best_feature_id = -2;
		GBDT_every_tree_first_node_array[i].node_split_value = 1e10;
		GBDT_every_tree_first_node_array[i].node_toSmaller_ptr = 0;
		GBDT_every_tree_first_node_array[i].node_toLarger_ptr = 0;
		GBDT_every_tree_first_node_array[i].node_this_node_sample_array = 0;
		GBDT_every_tree_first_node_array[i].node_this_node_sample_count = -2;
	}

	srand(time(0));
	color::setcolor("");
	cout << "configure--------------------------------------------------------------------------" << endl;
	cout << "GBDT_tree_count: ";
	color::setcolor("yellow");
	cout<< GBDT_tree_count << endl;
	color::setcolor("");
	cout << "GBDT_one_tree_max_node_count: ";
	color::setcolor("yellow");
	cout<< GBDT_one_tree_max_node_count << endl;
	color::setcolor("");
	cout << "GBDT_choose_features_count: ";
	color::setcolor("yellow");
	cout<< GBDT_choose_features_count << endl;
	color::setcolor("");
	cout << "GBDT_use_opt_splitpoint: ";
	color::setcolor("yellow");
	cout<< GBDT_use_opt_splitpoint << endl;
	color::setcolor("");
	cout << "GBDT_learn_rate: ";
	color::setcolor("yellow");
	cout<< GBDT_learn_rate << endl;
	color::setcolor("");
	cout << "GBDT_data_sample_ratio: ";
	color::setcolor("yellow");
	cout<< GBDT_data_sample_ratio << endl;
	cout << endl;

	return true;
}

bool GBDT::Train(const Data& data)
{
	GBDT_tree_Al_errors_array.resize(data.data_Al.size());
	this->GBDT_choose_features_count = this->GBDT_choose_features_count > data.data_all_features_count ? data.data_all_features_count : this->GBDT_choose_features_count;
	color::setcolor("");
	cout << "AboutTrees:------------------------------------------------------------------------" << endl;
	double pre_rmse = -1;
	unsigned int tree_id = 0;
	//TODO or rmse rise up
	for (; tree_id < GBDT_tree_count; tree_id++)
	{
		double rmse = 0.0;
		color::setcolor("red");
		cout << "����id: ";
		color::setcolor("green");
		cout<< tree_id << endl;

		ModelUpdate(data, tree_id, rmse);


		//if (pre_rmse < rmse && pre_rmse != -1)
		//if (pre_rmse - rmse < ( m_lrate * 0.001 ) && pre_rmse != -1)




		if (pre_rmse < rmse && pre_rmse != -1)
		{
			color::setcolor("red");
			cout << "debug: rmse:";
			color::setcolor("yellow");
			cout<< rmse << " ";
			color::setcolor("red");
			cout << "pre_rmse:";
			color::setcolor("yellow");
			cout << pre_rmse;
			color::setcolor("red");
			cout << "pre_rmse - rmse";
			color::setcolor("yellow");
			cout << pre_rmse-rmse<<endl;
			break;
		}
		pre_rmse = rmse;
	}
	GBDT_train_epoch = tree_id - 1;

	return true;
}

bool GBDT::ModelUpdate(const Data& data, unsigned int tree_id, double& rmse)
{
	int64_t t0 = Milliseconds();

	int nSamples = data.data_all_sample_count;//��������

	unsigned int nFeatures = data.data_all_features_count;//��������

	bool* usedFeatures = new bool[data.data_all_features_count];//������������

	T_DTYPE* all_data_array = new T_DTYPE[(nSamples + 1)*this->GBDT_choose_features_count];//(������+label)*������

	T_DTYPE* all_data_sort_array = new T_DTYPE[(nSamples + 1)*this->GBDT_choose_features_count];//��������

	int* Sample_Index_array = new int[nSamples];//��������

	//----first epoch----
	if (tree_id == 0)
	{
		double mean = 0.0;
		if (true)
		{
			for (unsigned int j = 0; j < data.data_all_sample_count; j++)
				mean += data.data_Al[j];//�������������ֵ
			mean /= (double)data.data_all_sample_count;//ÿ������ƽ�����
		}
		GBDT_mean_kwh = mean;
		color::setcolor("");
		std::cout << "Global Al(t) Mean:";
		color::setcolor("yellow");
		std::cout<< mean << " \n" << std::flush;

		//group by targets mean
		for (unsigned int j = 0; j < data.data_all_sample_count; j++)
			GBDT_tree_Al_errors_array[j] = data.data_Al[j] - mean;
	}

	deque< NodeToReduce > OneTreeNodeArray;//ɭ����ÿ���������ɼ��ڵ�ڵ�Ķ���
	//----init feature mask----
	for (unsigned int j = 0; j < data.data_all_features_count; j++)
		usedFeatures[j] = false;

	//----����ѡ������!!!!----
	int choose_sample_count = int(nSamples * GBDT_data_sample_ratio);//���ȡ������
	if (choose_sample_count < 10) choose_sample_count = nSamples;

	this->GBDT_every_tree_first_node_array[tree_id].node_this_node_sample_array = new int[choose_sample_count];
	this->GBDT_every_tree_first_node_array[tree_id].node_this_node_sample_count = choose_sample_count;
	int* ptr = this->GBDT_every_tree_first_node_array[tree_id].node_this_node_sample_array;

	set<int> used_data_ids;//���õ�����ID
	int sampled_count = 0;//�ѳ�ȡ����
	while (sampled_count < choose_sample_count)
	{
		int id = rand() % nSamples;//���ܵ����������ȡ����ID
		if (used_data_ids.find(id) == used_data_ids.end())//�������ù�������id��set�������ҵ���ǰ���������id
		{
			ptr[sampled_count] = id;
			sampled_count++;
			used_data_ids.insert(id);
		}
	}
	///////////////////

	//----��ʼ����һ���ڵ�----
	NodeToReduce firstNode;//��һ��������� �ɼ��ڵ�
	firstNode.NodeToReduce_node_ptr = &(this->GBDT_every_tree_first_node_array[tree_id]);//ɭ���еĵ�һ�����ĸ��ڵ�
	firstNode.NodeToReduce_sample_count = choose_sample_count;
	OneTreeNodeArray.push_back(firstNode);


	push_heap(OneTreeNodeArray.begin(), OneTreeNodeArray.end(), compareNodeReduced);  //���ڵ���ж�����ѡ������  ����д�Ĺ���compareNodeReduced

	//----���������в��Żس���(���ɭ�ֵĵڶ������)----
	int *randFeatureIDs = new int[this->GBDT_choose_features_count];
	if (this->GBDT_choose_features_count < data.data_all_features_count)
	{
		for (unsigned int i = 0; i < this->GBDT_choose_features_count; i++)
		{
			unsigned int idx = rand() % nFeatures; //���ܵ����������ȡ����ID
			while (usedFeatures[idx]) //����Ƿ������������id
				idx = rand() % nFeatures;
			//(data.data_not_used_features_id.find(idx) == data.data_not_used_features_id.end())
			randFeatureIDs[i] = idx;
			usedFeatures[idx] = true;
		}
	}
	else  // ������ò�����ѡ����������С������������ȡ��������
		for (unsigned int i = 0; i < this->GBDT_choose_features_count; i++)
			randFeatureIDs[i] = i;

	//----ѭ��������----
	// call trainSingleTree recursive for the largest node
	for (unsigned int j = 0; j < GBDT_one_tree_max_node_count; j++)
	{
		node* RootNode_ptr = OneTreeNodeArray[0].NodeToReduce_node_ptr;//ѡ��������Ľڵ㼴����������Ľڵ�

		int result=TrainSingleTree(
			RootNode_ptr,
			OneTreeNodeArray,
			data,
			usedFeatures,
			all_data_array,
			all_data_sort_array,
			Sample_Index_array,
			randFeatureIDs
		);
		if (result == 1)break;//���Ѿ���Ҷ�ӽڵ��˲���Ҫ�ٽ�����ȥ��

	}
	// unmark the selected inputs
	for (unsigned int i = 0; i < nFeatures; i++)
		usedFeatures[i] = false;

	//----delete the train lists per node, they are not necessary for prediction----
	cleanTree(&(GBDT_every_tree_first_node_array[tree_id]));

	// update the targets/residuals and calc train error
	double trainRMSE = 0.0;
	//fstream f("tmp/a0.txt",ios::out);
	for (int j = 0; j < nSamples; j++)
	{
		T_DTYPE p = predictSingleTree(&(GBDT_every_tree_first_node_array[tree_id]), data, j);

		//f<<p<<endl;
		GBDT_tree_Al_errors_array[j] -= GBDT_learn_rate * p;
		double err = GBDT_tree_Al_errors_array[j];
		trainRMSE += err * err;
	}
	rmse = sqrt(trainRMSE / (double)nSamples);
	color::setcolor("");
	cout << "RMSE:";
	color::setcolor("yellow");
	std::cout << rmse << " ";
	color::setcolor("");
	std::cout << "trainRMSE:"<<" ";
	color::setcolor("yellow");
	std::cout<< trainRMSE <<" "<< std::flush;
	color::setcolor("");
	cout << "CostTime: ";
	color::setcolor("yellow");
	cout << Milliseconds() - t0;
	color::setcolor("");
	cout<< "[ms]" << endl;

	delete[] usedFeatures;
	delete[] all_data_array;
	delete[] all_data_sort_array;
	delete[] Sample_Index_array;
	usedFeatures = NULL;
	all_data_array = NULL;
	all_data_sort_array = NULL;
	Sample_Index_array = NULL;
	return true;
}

void GBDT::cleanTree(node* n)
{
	if (n->node_this_node_sample_array)
	{
		delete[] n->node_this_node_sample_array;
		n->node_this_node_sample_array = 0;
	}
	//n->node_this_node_sample_count = 0;

	if (n->node_toSmaller_ptr)
		cleanTree(n->node_toSmaller_ptr);
	if (n->node_toLarger_ptr)
		cleanTree(n->node_toLarger_ptr);
}

/*ѵ��һ����*/


int GBDT::TrainSingleTree(
	node * RootNode_ptr,
	std::deque<NodeToReduce> &OneTreeNodeArray,
	const Data& data,
	bool* usedFeatures,
	T_DTYPE* all_data_array,
	T_DTYPE* all_data_sort_array,
	int* Sample_Index_array,
	const int* randFeatureIDs
)
{
	unsigned int nFeatures = data.data_all_features_count;//������

	// �жϱ�׼������С���ƻ�ѵ������̫��
	unsigned int nS = OneTreeNodeArray.size();
	if (nS >= GBDT_one_tree_max_node_count || RootNode_ptr->node_this_node_sample_count <= 1)
		return 1;

	//ɾ����ǰ�ڵ㣨��ǰ�Ƕ�����������Ԫ�أ�
	//һ���ڵ���ѳ���ڵ���ҽڵ������Կ���ɾ������ڵ�Ȼ�����ڵ���ҽڵ���д�����
	//���㷨�ö�ʵ�����滻�ݹ�
	if (OneTreeNodeArray.size() > 0)
	{
		//RootNodeArray.pop_front();
		pop_heap(OneTreeNodeArray.begin(), OneTreeNodeArray.end(), compareNodeReduced);//��С��������
		OneTreeNodeArray.pop_back();
	}

	// �˽ڵ��е�ѵ��������
	int nNodeSamples = RootNode_ptr->node_this_node_sample_count;

	// �������ܺ�ֵ �Լ��ܺĵ�ƽ��ֵ
	double sumTarget = 0.0, sum2Target = 0.0;
	for (int j = 0; j < nNodeSamples; j++)
	{
		T_DTYPE v = this->GBDT_tree_Al_errors_array[RootNode_ptr->node_this_node_sample_array[j]];
		sumTarget += v;
		sum2Target += v * v;
	}

	int bestFeature = -1, bestFeaturePos = -1;

	double bestFeatureRMSE = 1e10;

	T_DTYPE bestFeatureLow = 1e10, bestFeatureHi = 1e10;

	T_DTYPE optFeatureSplitValue = 1e10;


	//��� m_feature_subspace_sizeС�� nFeatures!!
	// ������ tmp ����������������ѷָ��
	for (unsigned int i = 0; i < this->GBDT_choose_features_count; i++)
	{
		// ѡ����ѷ��ѵ������ֵ ���ؽ��͵��ٶ�Խ��Խ��
		T_DTYPE optimalSplitValue = 0.0;
		double rmseBest = 1e10;
		T_DTYPE meanLowBest = 1e10, meanHiBest = 1e10;
		int bestPos = -1;
		double Low_sum = 0.0, Low2_sum = 0.0, Hi_sum = sumTarget, Hi2_sum = sum2Target, Low_count = 0.0, Hi_count = nNodeSamples;
		T_DTYPE* feature_value_array = all_data_array + i * nNodeSamples;
		T_DTYPE* Al_error_array = all_data_sort_array + i * nNodeSamples;

		//  ����ǰ��������������ֵ���Ƶ� preInput
 		int nr = randFeatureIDs[i];
		for (int j = 0; j < nNodeSamples; j++)
			feature_value_array[j] = data.data_data[RootNode_ptr->node_this_node_sample_array[j]][nr];  //�� :n->m_trainSamples[j] , ��:nr

		if (GBDT_use_opt_splitpoint == false) //ѡ����ѷ��ѵ�ر������ѡ����ѵ�
		{
			for (int j = 0; j < nNodeSamples; j++)
				Al_error_array[j] = this->GBDT_tree_Al_errors_array[RootNode_ptr->node_this_node_sample_array[j]];



			T_DTYPE* ptrInput = all_data_array + i * nNodeSamples;//
			bestPos = rand() % nNodeSamples;
			optimalSplitValue = ptrInput[bestPos];
			Low_sum = 0.0;
			Low2_sum = 0.0;
			Low_count = 0.0;
			Hi_sum = 0.0;
			Hi2_sum = 0.0;
			Hi_count = 0.0;
			for (int j = 0; j < nNodeSamples; j++)
			{
				//T_DTYPE v = ptrInput[j];
				T_DTYPE t = Al_error_array[j];
				if (ptrInput[j] <= optimalSplitValue)
				{
					Low_sum += t;
					Low2_sum += t * t;
					Low_count += 1.0;
				}
				else
				{
					Hi_sum += t;
					Hi2_sum += t * t;
					Hi_count += 1.0;
				}
			}
			rmseBest = (Low2_sum / Low_count - (Low_sum / Low_count) * (Low_sum / Low_count)) *Low_count;
			rmseBest += (Hi2_sum / Hi_count - (Hi_sum / Hi_count) * (Hi_sum / Hi_count)) *Hi_count;
			rmseBest = sqrt(rmseBest / (Low_count + Hi_count));
			meanLowBest = Low_sum / Low_count;
			meanHiBest = Hi_sum / Hi_count;
		}
		else  // Ѱ����ѷָ�㣬  Ŀ���ǣ����RMSE�����ָ� (�ع�����ָ�꣺����������RMSE����
		{
			for (int j = 0; j < nNodeSamples; j++)
				Sample_Index_array[j] = j;

			std::vector<std::pair<T_DTYPE, int> > list(nNodeSamples);
			for (int j = 0; j < nNodeSamples; j++)
			{
				list[j].first = feature_value_array[j];
				list[j].second = Sample_Index_array[j];
			}
			std::sort(list.begin(), list.end(),compare_kwh_mean);
			for (int j = 0; j < nNodeSamples; j++)
			{
				feature_value_array[j] = list[j].first;
				Sample_Index_array[j] = list[j].second;
			}
			for (int j = 0; j < nNodeSamples; j++)
				Al_error_array[j] = GBDT_tree_Al_errors_array[RootNode_ptr->node_this_node_sample_array[Sample_Index_array[j]]];

			int j = 0;

			while (j < nNodeSamples - 1)
			{
				/*�������������RMSE(Ԥ��ֵΪƽ���ܺ� ԭʼ����Ϊ�����������ܺ�)*/
				T_DTYPE Al_error = Al_error_array[j];
				Low_sum += Al_error;//����ԭʼ���ݺ�Ԥ��ֵ�Ĳ�ĺ���1+2+3
				Low2_sum += Al_error * Al_error;//�����ƽ���ĺ�1^2+2^2+3^2
				Hi_sum -= Al_error;//�ܵ�ԭʼ����(�ܺ�)֮�ͼ�ȥ(����ԭʼ���ݺ�Ԥ��ֵ�Ĳ�ĺ�) ��sumhi+sumlow=sumTarget
				Hi2_sum -= Al_error * Al_error;
				Low_count += 1.0;
				Hi_count -= 1.0;

				T_DTYPE feature_value = feature_value_array[j], v1 = 1e10;
				if (j < nNodeSamples - 1)
					v1 = feature_value_array[j + 1];
				if (feature_value == v1) // skip equal successors
				{
					j++;
					continue;
				}
				//����RMSE
				//double rmse = (Low2_sum / Low_count - (Low_sum / Low_count) * (Low_sum / Low_count)) *Low_count;
				double rmse = Low2_sum  - (Low_sum*Low_sum / Low_count);//����ƽ���ĺ�-���ĺ͵�ƽ��/������
				//rmse += (Hi2_sum / Hi_count - (Hi_sum / Hi_count) * (Hi_sum / Hi_count)) *Hi_count;
				rmse+=(Hi2_sum  - (Hi_sum*Hi_sum / Hi_count)) ;
				if (rmse < 0)
				{
					rmse = 0 - rmse;
				}
				rmse = sqrt(rmse / (Low_count + Hi_count));
				if (rmse < rmseBest)
				{
					optimalSplitValue = feature_value;
					rmseBest = rmse;
					bestPos = j + 1;
					meanLowBest = Low_sum / Low_count;
					meanHiBest = Hi_sum / Hi_count;
				}
				j++;
			}
		}

		if (rmseBest < bestFeatureRMSE)
		{
			bestFeature = i;
			bestFeaturePos = bestPos;
			bestFeatureRMSE = rmseBest;
			optFeatureSplitValue = optimalSplitValue;
			bestFeatureLow = meanLowBest;
			bestFeatureHi = meanHiBest;
		}


	}

	RootNode_ptr->node_best_feature_id = randFeatureIDs[bestFeature];
	RootNode_ptr->node_split_value = optFeatureSplitValue;

	if (RootNode_ptr->node_best_feature_id < 0 || RootNode_ptr->node_best_feature_id >= (int)nFeatures)
	{
		cout << "features��Ŵ�λ=" << RootNode_ptr->node_best_feature_id << endl;
		assert(false);
	}

	// count the samples of the low node
	int low_node_sample_count = 0;
	for (int i = 0; i < nNodeSamples; i++)
	{
		int nr = RootNode_ptr->node_best_feature_id;
		if (data.data_data[RootNode_ptr->node_this_node_sample_array[i]][nr] <= optFeatureSplitValue)
			low_node_sample_count++;
	}

	int* low_node_sample_array = new int[low_node_sample_count];
	int* high_node_sample_array = new int[nNodeSamples - low_node_sample_count];
	if (low_node_sample_count == 0)
		low_node_sample_array = 0;
	if (nNodeSamples - low_node_sample_count == 0)
		high_node_sample_array = 0;

	int lowCnt = 0, hiCnt = 0;
	double lowMean = 0.0, hiMean = 0.0;
	for (int i = 0; i < nNodeSamples; i++)
	{
		int nr = RootNode_ptr->node_best_feature_id;
		if (data.data_data[RootNode_ptr->node_this_node_sample_array[i]][nr] <= optFeatureSplitValue)
		{
			low_node_sample_array[lowCnt] = RootNode_ptr->node_this_node_sample_array[i];
			lowMean += GBDT_tree_Al_errors_array[RootNode_ptr->node_this_node_sample_array[i]];
			lowCnt++;
		}
		else
		{
			high_node_sample_array[hiCnt] = RootNode_ptr->node_this_node_sample_array[i];
			hiMean += GBDT_tree_Al_errors_array[RootNode_ptr->node_this_node_sample_array[i]];
			hiCnt++;
		}
	}
	lowMean /= lowCnt;
	hiMean /= hiCnt;

	if (hiCnt + lowCnt != nNodeSamples || lowCnt != low_node_sample_count)
		assert(false);
	///////////////////////////

	// ֹͣ������ ��Ϊ�Ѿ���Ҷ�ӽڵ���
	if (lowCnt < 1 || hiCnt < 1)
	{
		RootNode_ptr->node_best_feature_id = -1;
		RootNode_ptr->node_split_value = lowCnt < 1 ? hiMean : lowMean;
		RootNode_ptr->node_toSmaller_ptr = 0;
		RootNode_ptr->node_toLarger_ptr = 0;
		if (RootNode_ptr->node_this_node_sample_array)
			delete[] RootNode_ptr->node_this_node_sample_array;
		RootNode_ptr->node_this_node_sample_array = 0;
		RootNode_ptr->node_this_node_sample_count = 0;

		NodeToReduce currentNode;
		currentNode.NodeToReduce_node_ptr = RootNode_ptr;
		currentNode.NodeToReduce_sample_count = 0;
		OneTreeNodeArray.push_back(currentNode);
		push_heap(OneTreeNodeArray.begin(), OneTreeNodeArray.end(), compareNodeReduced);

		return 2;
	}

	// ��ʼ����ڵ�
	RootNode_ptr->node_toSmaller_ptr = new node;
	RootNode_ptr->node_toSmaller_ptr->node_best_feature_id = -3;
	RootNode_ptr->node_toSmaller_ptr->node_split_value = lowMean;
	RootNode_ptr->node_toSmaller_ptr->node_toSmaller_ptr = 0;
	RootNode_ptr->node_toSmaller_ptr->node_toLarger_ptr = 0;
	RootNode_ptr->node_toSmaller_ptr->node_this_node_sample_array = low_node_sample_array;
	RootNode_ptr->node_toSmaller_ptr->node_this_node_sample_count = lowCnt;

	// ��ʼ���ҽڵ�
	RootNode_ptr->node_toLarger_ptr = new node;
	RootNode_ptr->node_toLarger_ptr->node_best_feature_id = -3;
	RootNode_ptr->node_toLarger_ptr->node_split_value = hiMean;
	RootNode_ptr->node_toLarger_ptr->node_toSmaller_ptr = 0;
	RootNode_ptr->node_toLarger_ptr->node_toLarger_ptr = 0;
	RootNode_ptr->node_toLarger_ptr->node_this_node_sample_array = high_node_sample_array;
	RootNode_ptr->node_toLarger_ptr->node_this_node_sample_count = hiCnt;

	// �������ӽڵ���뵽heap ����
	NodeToReduce lowNode, hiNode;
	lowNode.NodeToReduce_node_ptr = RootNode_ptr->node_toSmaller_ptr;
	lowNode.NodeToReduce_sample_count = lowCnt;
	hiNode.NodeToReduce_node_ptr = RootNode_ptr->node_toLarger_ptr;
	hiNode.NodeToReduce_sample_count = hiCnt;

	OneTreeNodeArray.push_back(lowNode);
	push_heap(OneTreeNodeArray.begin(), OneTreeNodeArray.end(), compareNodeReduced);

	OneTreeNodeArray.push_back(hiNode);
	push_heap(OneTreeNodeArray.begin(), OneTreeNodeArray.end(), compareNodeReduced);
	return 0;
}

T_DTYPE GBDT::predictSingleTree(node* n, const Data& data, int data_index)
{
	int nFeatures = data.data_all_features_count;
	int nr = n->node_best_feature_id;
	if (nr < -3 || nr >= nFeatures)
	{
		cout << "Feature nr:" << nr << endl;
		assert(false);
	}

	// ���������Ҷ���ϣ���Ԥ�ⳣ��ֵ
	if (n->node_toSmaller_ptr == 0 && n->node_toLarger_ptr == 0)
		return n->node_split_value;

	//TODO : �ظ����
	if (nr < -3 || nr >= nFeatures)
	{
		cout << endl << "Feature nr: " << nr << " (max:" << nFeatures << ")" << endl;
		assert(false);
	}
	T_DTYPE thresh = n->node_split_value;
	T_DTYPE feature = data.data_data[data_index][nr];

	if (feature <= thresh)
		return predictSingleTree(n->node_toSmaller_ptr, data, data_index);
	return predictSingleTree(n->node_toLarger_ptr, data, data_index);

}

void GBDT::PredictAllOutputs(const Data& data, T_VECTOR& predictions)
{
	unsigned int nSamples = data.data_all_sample_count;
	predictions.resize(nSamples);

	// predict all values 
	for (unsigned int i = 0; i < nSamples; i++)
	{
		double sum = GBDT_mean_kwh;
		// for every boosting epoch : CORRECT, but slower
		for (unsigned int k = 0; k < GBDT_train_epoch + 1; k++)
		{
			T_DTYPE v = predictSingleTree(&(GBDT_every_tree_first_node_array[k]), data, i);
			sum += GBDT_learn_rate * v;  // this is gradient boosting
		}
		predictions[i] = sum;
	}
}

void GBDT::SaveWeights(const std::string& model_file)
{
	color::setcolor("");
	cout << "Save:" << model_file << endl;
	std::fstream f(model_file.c_str(), std::ios::out|std::ios::binary);

	// save learnrate
	f.write((char*)&GBDT_learn_rate, sizeof(GBDT_learn_rate));

	// save number of 
	f.write((char*)&GBDT_train_epoch, sizeof(GBDT_train_epoch));

	// save global means
	f.write((char*)&GBDT_mean_kwh, sizeof(GBDT_mean_kwh));

	// save trees
	for (unsigned int j = 0; j < GBDT_train_epoch + 1; j++)
		SaveTreeRecursive(&(GBDT_every_tree_first_node_array[j]), f);
	color::setcolor("");
	cout << "debug: train_epoch: ";
	color::setcolor("yellow");
	cout<< GBDT_train_epoch << endl;
	f.close();
}

void GBDT::SaveTreeRecursive(node* n, std::fstream &f)
{
	if (n->node_best_feature_id != -3)
	{
		color::setcolor("");
		cout << "debug_save: " << "feature_id: ";
		color::setcolor("yellow");
		cout << n->node_best_feature_id << " ";
		color::setcolor("");
		cout << "feature_vaule: ";
		color::setcolor("yellow");
		cout<< n->node_split_value << endl;
	}

	f.write((char*)n, sizeof(node));
	if (n->node_toSmaller_ptr)
		SaveTreeRecursive(n->node_toSmaller_ptr, f);
	if (n->node_toLarger_ptr)
		SaveTreeRecursive(n->node_toLarger_ptr, f);
}

bool GBDT::LoadWeights(const std::string& model_file,QTextEdit *textEdit)
{
	
	textEdit->append("Load:");
	textEdit->append(model_file.c_str());
	textEdit->append("<br/>");
	std::fstream f(model_file.c_str(), std::ios::in | std::ios::binary);
	if (f.is_open() == false)
	{
		textEdit->append("Load:");
		textEdit->append(model_file.c_str()); 
		textEdit->append("failed!!!");
		textEdit->append("<br/>");
		return false;
	}

	// load learnrate
	f.read((char*)&GBDT_learn_rate, sizeof(GBDT_learn_rate));

	// load number of epochs
	f.read((char*)&GBDT_train_epoch, sizeof(GBDT_train_epoch));

	// load global means
	f.read((char*)&GBDT_mean_kwh, sizeof(GBDT_mean_kwh));

	// allocate and load the trees
	GBDT_every_tree_first_node_array = new node[GBDT_train_epoch + 1];
	for (unsigned int j = 0; j < GBDT_train_epoch + 1; j++)
	{
		std::string prefix = "";
		LoadTreeRecursive(&(GBDT_every_tree_first_node_array[j]), f, prefix);
	}

	f.close();
	return true;
}

void GBDT::LoadTreeRecursive(node* n, std::fstream &f, std::string prefix)
{
	f.read((char*)n, sizeof(node));

	//cout << prefix;
	if (n->node_toLarger_ptr == 0 && n->node_toSmaller_ptr == 0)
	{
		assert(n->node_best_feature_id == -3);
	}
	if (n->node_toSmaller_ptr)
	{
  		n->node_toSmaller_ptr = new node;
		LoadTreeRecursive(n->node_toSmaller_ptr, f, prefix);
	}
	if (n->node_toLarger_ptr)
	{
		n->node_toLarger_ptr = new node;
		LoadTreeRecursive(n->node_toLarger_ptr, f, prefix);
	}
}

